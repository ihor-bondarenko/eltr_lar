const ipcRenderer = window.ipcRenderer

export {ipcRenderer};
